This is the description that appears below your visualization in Auspice. Edit me in `my_profiles/Nextstrain_mytest/my_description.md`.
